"""Unreal Engine 5 backend: Semantic IR -> Unreal Editor Python."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from ... import __version__
from ...common.names import NameAllocator, unreal_asset_name
from ...compiler.diagnostics import DiagnosticBag
from ...compiler.subgraphs import inline_where
from ...ir.graph import TreeKind
from ...ir.semantic import SemanticGraph
from ...ir.types import DataType
from ...translation.confidence import Classification, Confidence as C
from ...translation.registry import translator
from ..base import GeneratedCode, TargetBackend
from ..codegen import PyWriter, clean_number, literal
from ..registry import register_backend
from .materials import write_material
from .pcg import PcgBuilder
from .postprocess import write_postprocess
from .pyexpr import control_name
from .runtime import HELPERS, MATERIAL_HELPERS, PCG_HELPERS

if TYPE_CHECKING:
    from ...compiler.pipeline import CompilationResult

FIELD_KINDS = (
    "MATH", "VECTOR_MATH", "COMBINE_VECTOR", "SEPARATE_VECTOR", "MAP_RANGE", "COMPARE", "BOOLEAN_MATH", "RANDOM", "NOISE",
    "VORONOI", "FIELD_INPUT", "ATTRIBUTE_READ", "MIX", "COLOR_RAMP", "PROXIMITY", "RAYCAST", "ALIGN_ROTATION", "SAMPLE", "INTERPOLATE",
)
FIELD_REASON = "Per-element field expressions cannot be built with PCG's Python API; only recognized patterns (random ranges, noise masks) are translated."


def _field_classify(op, graph, base):
    if not any(ref.field for ref in op.outputs.values()):
        return Classification(C.EXACT, "Single value evaluated as a script-level expression over the controls.", "Python expression")
    return None


for _kind in FIELD_KINDS:
    translator(_kind, target="unreal", context="pcg", confidence=C.UNSUPPORTED, implementation="none", explanation=FIELD_REASON, classify=_field_classify)(lambda b, op: None)


class UnrealBackend(TargetBackend):
    id = "unreal"
    display_name = "Unreal Engine 5"
    language_label = "Unreal Editor Python"
    coordinate_system = "unreal"
    required_imports = ("unreal",)
    contexts = {TreeKind.GEOMETRY: "pcg", TreeKind.SHADER: "material", TreeKind.COMPOSITOR: "postprocess"}
    context_labels = {"pcg": "PCG graph", "material": "Material asset", "postprocess": "Post Process Volume"}

    def prepare(self, graph: SemanticGraph, diagnostics: DiagnosticBag) -> SemanticGraph:
        inline_where(graph, lambda g, op: True, diagnostics, "PCG subgraph / material function assets are not generated yet")
        mesh = {"EXTRUDE", "SUBDIVIDE", "BOOLEAN", "CURVE", "CURVE_RESAMPLE", "CURVE_TO_MESH", "MESH_TO_CURVE"}
        if graph.kind == TreeKind.GEOMETRY and any(op.kind in mesh for op in graph.topological_order()):
            diagnostics.warning(
                "unreal.pcg_mesh",
                "PCG does not model meshes, so extrude and curves stay unsupported; build that geometry in Houdini or spawn a Static Mesh.",
            )
        return graph

    def generate(self, result: "CompilationResult") -> GeneratedCode:
        w = PyWriter()
        kind = result.semantic.kind
        self._header(w, result)
        variables = NameAllocator({"graph", "material", "materials", "settings", "volume", "input_node", "output_node", "build", "unreal", "math"})
        if kind == TreeKind.GEOMETRY:
            self._pcg(w, result, variables)
        elif kind == TreeKind.SHADER:
            w.block(MATERIAL_HELPERS)
            w.blank()
            function = write_material(self, result, w, variables)
            w.blank()
            w.line("def build():")
            w.line(f"    return {function}()")
            w.blank()
            w.line("material = build()")
            w.line('print("NodeBridge: created", material.get_path_name())')
        else:
            write_postprocess(self, result, w)
            w.blank()
            w.line("volume = build()")
            w.line('print("NodeBridge: created post process volume", volume.get_actor_label())')
        w.line("for nb_warning in NB_WARNINGS:")
        w.line('    unreal.log_warning("NodeBridge: " + nb_warning)')
        name = unreal_asset_name(result.document.root)
        code = w.text()
        if "math." not in code.split('ASSET_PATH = "/Game/NodeBridge"', 1)[1]:
            code = code.replace("import math\n\n", "", 1)
        if len(re.findall(r"\binput_node\b", code)) == 1:
            code = code.replace("    input_node = graph.get_input_node()\n", "", 1)
        instructions = (
            "Unreal Editor: Save .py, then Tools > Execute Python Script (needs the Python Editor Script Plugin). "
            "Pasting into the Output Log's Python console also works where multi-line input is supported."
        )
        if kind == TreeKind.GEOMETRY:
            instructions += (
                " Exposed inputs are constants at the top of the script. "
                "PCG graph parameters are not created until a live Unreal session confirms that API. Edit the constants and run the script again."
            )
        return GeneratedCode(
            target=self.id,
            language="python",
            filename=f"nodebridge_{name}_unreal.py",
            code=code,
            run_instructions=instructions,
        )

    def _header(self, w: PyWriter, result: "CompilationResult") -> None:
        report = result.report
        counts = report.counts
        w.line('"""NodeBridge: generated Unreal Editor Python.')
        w.line("")
        w.line(f"Source:  {report.source_kind} / {report.source_name}" + (f" ({report.source_application})" if report.source_application else ""))
        w.line(f"Target:  {report.target_label}")
        w.line(f"Translation: {counts['EXACT']} exact, {counts['EQUIVALENT']} equivalent, {counts['APPROXIMATE']} approximate, {counts['UNSUPPORTED']} unsupported")
        w.line(f"Generated by NodeBridge {__version__}.")
        w.line("")
        w.line("Run inside the Unreal Editor with the Python Editor Script Plugin enabled:")
        w.line("save this file, then Tools > Execute Python Script (or paste into the Output Log's Python console).")
        if result.semantic.kind == TreeKind.GEOMETRY:
            w.line("Requires the PCG plugin. The PCG Python API is experimental (UE 5.4+); anything")
            w.line("this editor version does not expose is listed as a NodeBridge warning in the log.")
        w.line("New assets are created under ASSET_PATH; existing assets are never overwritten.")
        w.line('"""')
        w.line("import math")
        w.line("")
        w.line("import unreal")
        w.blank()
        w.line('ASSET_PATH = "/Game/NodeBridge"')
        if result.semantic.kind == TreeKind.GEOMETRY:
            w.line("SPAWN_PCG_VOLUME = False  # True: also place a PCG Volume using the new graph")
        self._controls(w, result.semantic)
        w.block(HELPERS)
        w.blank()

    def _controls(self, w: PyWriter, graph: SemanticGraph) -> None:
        if not graph.parameters or graph.kind != TreeKind.GEOMETRY:
            return
        w.blank()
        w.comment("Controls (Blender group inputs, Blender units). These are script constants, not live PCG parameters. Edit and re-run to rebuild the graph.")
        for p in graph.parameters:
            value = p.current
            if isinstance(value, dict):
                value = value.get("name", "")
            elif isinstance(value, (list, tuple)):
                value = tuple(clean_number(float(v)) for v in value)
            elif isinstance(value, float):
                value = clean_number(value)
            elif p.data_type == DataType.BOOL:
                value = bool(value)
            w.line(f"{control_name(p.key)} = {literal(value)}  # {p.name}")

    def _pcg(self, w: PyWriter, result: "CompilationResult", variables: NameAllocator) -> None:
        w.block(PCG_HELPERS)
        material_exprs = {}
        if result.materials:
            w.block(MATERIAL_HELPERS)
            w.blank()
            w.line("def build_materials():")
            w.indent()
            w.line("created = {}")
            for name, sub in result.materials.items():
                w.blank()
                inner = PyWriter()
                function = write_material(self, sub, inner, NameAllocator(set(variables._used)))
                w.block(inner.text())
                w.line(f"created[{name!r}] = {function}()")
            w.line("return created")
            w.dedent()
            material_exprs = {name: f"materials.get({name!r})" for name in result.materials}
        w.blank()
        w.line("def build():")
        w.indent()
        if result.materials:
            w.line("materials = build_materials()")
        w.line('factory_class = getattr(unreal, "PCGGraphFactory", None)')
        w.line(f'graph = nb_create_asset("{unreal_asset_name(result.semantic.name, "PCG_")}", ASSET_PATH, unreal.PCGGraph, factory_class() if factory_class else None)')
        w.line("input_node = graph.get_input_node()")
        w.line("output_node = graph.get_output_node()")
        builder = PcgBuilder(self, result, w, variables)
        builder.materials = material_exprs
        builder.build()
        w.blank()
        w.line("unreal.EditorAssetLibrary.save_loaded_asset(graph)")
        w.line("if SPAWN_PCG_VOLUME:")
        w.line("    actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)")
        w.line("    volume = actors.spawn_actor_from_class(unreal.PCGVolume, unreal.Vector(0.0, 0.0, 0.0))")
        w.line("    component = volume.get_component_by_class(unreal.PCGComponent)")
        w.line("    component.set_graph(graph)")
        w.line("return graph")
        w.dedent()
        w.blank()
        w.line("graph = build()")
        w.line('print("NodeBridge: created", graph.get_path_name())')


register_backend(UnrealBackend())
